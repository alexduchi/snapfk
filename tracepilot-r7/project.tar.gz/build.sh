#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"; [ -n "$SDK" ]
BT="$(find "$SDK/build-tools" -mindepth 1 -maxdepth 1 -type d | sort -V | tail -1)"; PLAT="$(find "$SDK/platforms" -mindepth 1 -maxdepth 1 -type d -name 'android-*' | sort -V | tail -1)"; JAR="$PLAT/android.jar"
for f in "$BT/aapt2" "$BT/d8" "$BT/zipalign" "$JAR"; do [ -e "$f" ] || { echo "missing $f"; exit 2;}; done
rm -rf "$ROOT/build" "$ROOT/dist";mkdir -p "$ROOT/build/gen" "$ROOT/build/classes" "$ROOT/build/dex" "$ROOT/dist"
"$BT/aapt2" compile --dir "$ROOT/app/src/main/res" -o "$ROOT/build/res.zip"
"$BT/aapt2" link -o "$ROOT/build/base.apk" -I "$JAR" --manifest "$ROOT/app/src/main/AndroidManifest.xml" --java "$ROOT/build/gen" --min-sdk-version 26 --target-sdk-version 28 "$ROOT/build/res.zip"
find "$ROOT/app/src/main/java" "$ROOT/build/gen" -name '*.java' -print0|xargs -0 javac -encoding UTF-8 -source 8 -target 8 -classpath "$JAR" -d "$ROOT/build/classes"
(cd "$ROOT/build/classes"&&jar cf "$ROOT/build/classes.jar" .)
"$BT/d8" --lib "$JAR" --min-api 26 --output "$ROOT/build/dex" "$ROOT/build/classes.jar"
cp "$ROOT/build/base.apk" "$ROOT/build/u.apk";(cd "$ROOT/build/dex"&&zip -q -j "$ROOT/build/u.apk" classes*.dex)
"$BT/zipalign" -f -p 4 "$ROOT/build/u.apk" "$ROOT/dist/TracePilot-R7-FULLCORE-UNSIGNED.apk"
unzip -t "$ROOT/dist/TracePilot-R7-FULLCORE-UNSIGNED.apk";"$BT/aapt2" dump badging "$ROOT/dist/TracePilot-R7-FULLCORE-UNSIGNED.apk"|head -20
sha256sum "$ROOT/dist/TracePilot-R7-FULLCORE-UNSIGNED.apk" > "$ROOT/dist/TracePilot-R7-FULLCORE-UNSIGNED.apk.sha256"
(cd "$ROOT"&&zip -qr "$ROOT/dist/TracePilot-R7-source.zip" app build.sh -x '*/build/*' '*/dist/*')
